# BISSAU DRIP — projeto inicial Android

Este é um protótipo inicial em Kotlin + Jetpack Compose para abrir no Android Studio.

## Incluído
- Catálogo de produtos de demonstração com preços em FCFA
- Carrinho e cálculo do total
- Formulário de encomenda (nome, telefone e local de entrega)
- Pagamento na entrega
- Lista de encomendas e atualização de estado
- Ecrã de administração para adicionar produtos

## Limitações importantes desta versão
- Os dados ficam apenas na memória: ao fechar a app, os produtos e as encomendas são reiniciados.
- A área de administração ainda não tem autenticação.
- Não há servidor/base de dados partilhada: esta versão é uma demonstração local, não está pronta para receber encomendas reais de vários clientes.
- As imagens dos produtos são placeholders; devem ser substituídas por fotografias reais.
- Os preços de demonstração devem ser alterados para os preços reais da loja.

## Como gerar um APK
1. Instala o Android Studio num computador.
2. Descomprime esta pasta e abre `BissauDrip` no Android Studio.
3. Aguarda a sincronização do Gradle e instala os componentes Android SDK pedidos.
4. Usa **Build > Build APK(s)**.
5. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Próximo passo recomendado antes de usar com clientes
Adicionar autenticação de administrador e uma base de dados online (por exemplo, Firebase ou Supabase), para que as encomendas cheguem ao proprietário e não se percam quando a aplicação fecha.


## Compilar usando apenas o telemóvel (GitHub Actions)

Este projeto inclui `.github/workflows/android-apk.yml`, para pedir a compilação na nuvem sem instalar Android Studio no telemóvel.

1. No navegador do telemóvel, cria/inicia sessão em https://github.com/.
2. Cria um repositório novo chamado `BissauDripAndroid`.
3. Carrega os ficheiros deste ZIP para o repositório, mantendo as pastas e incluindo a pasta oculta `.github`.
   Se o site móvel não permitir enviar uma pasta inteira, usa o GitHub Desktop num computador emprestado ou uma aplicação Git compatível com Android.
4. Abre o separador **Actions** do repositório e seleciona **Build BISSAU DRIP APK**.
5. Carrega em **Run workflow** (ou espera pela execução automática depois de enviares para `main`).
6. Quando o trabalho terminar com sucesso, abre a execução e transfere o artefacto `BISSAU-DRIP-debug-APK`. Dentro estará `app-debug.apk`.
7. Abre o APK no telemóvel e autoriza a instalação a partir do navegador/gestor de ficheiros, se o Android pedir.

**Atenção:** a compilação na nuvem produz um APK de teste, não um lançamento assinado para a Play Store. O protótipo guarda os dados temporariamente no dispositivo e não deve ser usado para encomendas reais até adicionarmos base de dados online e autenticação de administrador.
